package com.edusupport.helpdesk;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Ticket {
    @Id @GeneratedValue
    private Long id;
    private String issue;
    private String student;
    private String category; // Fees, ID Card, Certificate...
    private String priority; // HIGH, MEDIUM, LOW
    private String status = "OPEN"; // OPEN, IN_PROGRESS, PENDING, RESOLVED
    private String assignedTo = "Unassigned";
    private LocalDateTime createdAt = LocalDateTime.now();
    private LocalDateTime slaDeadline;
    private String resolutionNotes;

    // Getters & Setters
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public String getIssue(){return issue;}
    public void setIssue(String issue){this.issue=issue;}
    public String getStudent(){return student;}
    public void setStudent(String student){this.student=student;}
    public String getCategory(){return category;}
    public void setCategory(String category){this.category=category;}
    public String getPriority(){return priority;}
    public void setPriority(String priority){
        this.priority=priority;
        // Auto SLA
        if("HIGH".equals(priority)) this.slaDeadline = LocalDateTime.now().plusHours(24);
        else if("MEDIUM".equals(priority)) this.slaDeadline = LocalDateTime.now().plusHours(48);
        else this.slaDeadline = LocalDateTime.now().plusHours(72);
    }
    public String getStatus(){return status;}
    public void setStatus(String status){this.status=status;}
    public String getAssignedTo(){return assignedTo;}
    public void setAssignedTo(String assignedTo){this.assignedTo=assignedTo;}
    public LocalDateTime getCreatedAt(){return createdAt;}
    public LocalDateTime getSlaDeadline(){return slaDeadline;}
    public String getResolutionNotes(){return resolutionNotes;}
    public void setResolutionNotes(String resolutionNotes){this.resolutionNotes=resolutionNotes;}
}