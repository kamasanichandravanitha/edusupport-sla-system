package com.edusupport.helpdesk;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/tickets")
public class TicketController {
    @Autowired
    TicketRepository repo;

    @GetMapping
    public List<Ticket> getAll() {
        return repo.findAll();
    }

    @PostMapping
    public Ticket create(@RequestBody Ticket t) {
        if(t.getStatus()==null) t.setStatus("OPEN");
        return repo.save(t);
    }

    @PutMapping("/{id}")
    public Ticket update(@PathVariable Long id, @RequestBody Ticket u) {
        Ticket t = repo.findById(id).orElseThrow();
        if(u.getStatus()!=null) t.setStatus(u.getStatus());
        if(u.getAssignedTo()!=null) t.setAssignedTo(u.getAssignedTo());
        if(u.getResolutionNotes()!=null) t.setResolutionNotes(u.getResolutionNotes());
        return repo.save(t);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        repo.deleteById(id);
    }
}